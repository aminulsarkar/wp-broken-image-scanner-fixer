<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', function () {
    add_menu_page(
        __('Broken Images Scanner & Fixer','wp-sbif'),
        __('Broken Images Scanner','wp-sbif'),
        'manage_options',
        'wp-bif',
        'wp_bif_admin_page',
        'dashicons-format-image'
    );
});

function wp_bif_admin_page() {
    
    // Get stored results
    $results = get_option( 'wp_bif_scan_results', [] );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Broken Image Scanner & Fixer','wp-sbif'); ?></h1>

        <!-- AJAX Scan Button -->
        <form method="post" id="wp-bif-scan-form">
            <?php wp_nonce_field( 'wp_bif_scan' ); ?>
            <p>
                <button class="button button-primary" name="wp_bif_scan">
                    <?php esc_html_e('Scan for Broken Images','wp-sbif'); ?>
                </button>
            </p>
        </form>

        <!-- Result Box -->
        <div id="wp-bif-results">
            <?php wp_bif_render_results_table($results); ?>
        </div>
    </div>
    <?php
}
