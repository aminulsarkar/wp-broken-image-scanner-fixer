<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Scan posts for broken images
function wp_bif_scan_posts() {
    $post_types = get_post_types(['public' => true]); // all public
$args = [
    'post_type' => $post_types,
    'post_status' => 'publish',
    'posts_per_page' => -1
];


    $posts = get_posts( $args );
    $results = [];

    foreach ( $posts as $post ) {
        if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\']/', $post->post_content, $matches ) ) {
            foreach ( $matches[1] as $img ) {
                if ( wp_bif_is_broken_image( $img ) ) {
                    $results[] = [
                        'post_id'    => $post->ID,
                        'post_title' => $post->post_title,
                        'img_url'    => $img,
                    ];
                }
            }
        }
    }

    // Save results for persistent display
    update_option( 'wp_bif_scan_results', $results );

    return $results;
}

// Check if an image URL is broken
function wp_bif_is_broken_image( $url ) {
    $response = wp_remote_head( $url, ['timeout' => 5] );
    if ( is_wp_error( $response ) ) return true;
    $code = wp_remote_retrieve_response_code( $response );
    return ( $code >= 400 );
}

// Render results table
// Render results table
function wp_bif_render_results_table($results, $after_scan = false) {
    
    $count = count($results);
    echo '<div style="margin-bottom: 10px; text-align: right; font-weight: bold;">';
    echo __('Results found: ','wp-sbif') . $count;
    echo '</div>';

    echo '<table class="widefat striped">';
    echo '<tr><th>'.__("Post","wp-sbif").'</th><th>'.__("Broken Image URL","wp-sbif").'</th></tr>';

    if ( empty($results) ) {
        // Empty row with message
        echo '<tr>';
        echo '<td colspan="2" style="text-align:center; color: #777;">'.__("No broken images found","wp-sbif").'</td>';
        echo '</tr>';
    } else {
        foreach ($results as $item) {
    echo '<tr>';
    echo '<td><a href="' . esc_url(get_permalink($item['post_id'])) . '" target="_blank">' . esc_html($item['post_title']) .' '.'<b>'.esc_html__('Go fix','wp-sbif').'</b>'. '</a></td>';
    echo '<td><a href="' . esc_url($item['img_url']) . '" target="_blank" style="color:red;">' . esc_url($item['img_url']) . '</a></td>';
    echo '</tr>';
}

    }

    echo '</table>';
}

/**
 * Helper function to get permalink by post title
 */
function get_permalink_by_title($title) {
    $post = get_page_by_title($title, OBJECT, ['post','page']);
    return $post ? get_permalink($post->ID) : '#';
}




// AJAX scan handler
add_action('wp_ajax_wp_bif_scan', function () {
    check_ajax_referer('wp_bif_scan');

    $results = wp_bif_scan_posts();

    ob_start();
    wp_bif_render_results_table($results, true); // <-- after scan
    wp_send_json_success( ob_get_clean() );
});

