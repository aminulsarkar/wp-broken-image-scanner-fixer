jQuery(function($){
    $('button[name="wp_bif_scan"]').on('click', function(e){
        e.preventDefault();

        let btn = $(this);
        btn.text('Scanning...').prop('disabled', true);

        $.post(wpBIF.ajax, {
            action: 'wp_bif_scan',
            _ajax_nonce: wpBIF.nonce
        }, function(res){
            btn.text('Scan for Broken Images').prop('disabled', false);
            if (res.success) {
                // 🔹 Replace previous results instead of appending
                $('#wp-bif-results').html(res.data);
            }
        });
    });
});
